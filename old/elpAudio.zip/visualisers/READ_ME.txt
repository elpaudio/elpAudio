These folder contains visualisers for elpAudio.
For making your own visualiser please read GameMaker 8.1 documentation (and only that).
And for working visualisers please NAME THEM AS "vis_0.gml", "vis_1.gml", "vis_*.gml" and others...
DO NOT MAKE VISUALISERS NAMED LIKE THIS:
"vis_0.gml"
"vis_2.gml"
elpAudio WILL CRASH BECAUSE IT CAN'T SEE vis_1.gml FILE!

For variables information read data/vars.txt file.

For vis_1.gml documentation read data/doc.rtf file.